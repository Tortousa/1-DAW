import Classes.Config;
import Classes.Input;
import Classes.Session;

public class Main {
	public static Session currentSession = new Session();
	
	public static void main(String[] args) {
	    System.out.println(Config.WELLCOME);
	    int option;

	    do {
	        if (currentSession.isLogged()) {
	            option = Input.getInt(Config.LOGGED_MENU);
	           
	        } else {
	            option = Input.getInt(Config.UNLOGGED_MENU);
	            
	        }
	    } while (option != 0);

	    System.out.println(Config.GOODBYE);
	}
	public static void loggedAction(int option) {
		if(option == 1) {
			
		}else if(option == 2) {
			
		}else if(option == 3) {
			
		}else if(option == 4) {
			
		}else if(option == 5) {
			
		}else if(option == 6) {
			
		}
	}
	public static void unloggedAction(int option) {
		if(option == 1) {
			
		}else if(option == 2) {
			
		}else if(option == 3) {
			
		}
			
	}
}
