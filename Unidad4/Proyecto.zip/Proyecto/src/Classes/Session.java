package Classes;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Session {
    private User user;
    private ArrayList<User> users;
    private boolean logged;
    private final String FILE_PATH = ".\\assets\\files\\";
    private final String USERS_FILE = "users.txt";

    public Session() {
        this.logged = false;
    }

    public void login() {
        readUsersFromFile();

        System.out.print("Nombre de usuario: ");
        String enteredUsername = Input.getString();
        System.out.print("Contraseña: ");
        String enteredPassword = Input.getString();

        for (User storedUser : getUsersFromFile()) {
            if (enteredUsername.equals(storedUser.getUsername()) && enteredPassword.equals(storedUser.getPassword())) {
                user = storedUser;
                logged = true;
                System.out.println("Inicio de sesión exitoso.");
                return;
            }
        }

        System.out.println("Usuario y/o contraseña no válidos.");
    }

    public void signup() {
        readUsersFromFile();

        System.out.print("Nombre de usuario: ");
        String newUsername = Input.getString();

        if (isUsernameTaken(newUsername)) {
            System.out.println("El nombre de usuario ya está en uso. Inténtalo de nuevo.");
            return;
        }

        System.out.print("Contraseña: ");
        String newPassword = Input.getString();
        System.out.print("Nombre completo: ");
        String newName = Input.getString();
        System.out.print("NIF: ");
        String newNif = Input.getString();
        System.out.print("Email: ");
        String newEmail = Input.getString();
        System.out.print("Dirección: ");
        String newAddress = Input.getString();
        System.out.print("Fecha de nacimiento: ");
        String newBirthdate = Input.getString();
        System.out.print("Rol: ");
        String newRole = Input.getString();

        User newUser = new User(newUsername, newName, newNif, newEmail, newAddress, newBirthdate, newRole);
        newUser.setPassword(newPassword);

        users.add(newUser);
        writeUsersToFile();

        System.out.println("Usuario registrado con éxito.");
    }

    public boolean isLogged() {
        return this.logged;
    }

    public void showUser() {
        if (logged) {
            System.out.println("Información del usuario actual:");
            System.out.println("Username: " + user.getUsername());
            System.out.println("Nombre: " + user.getName());
            System.out.println("NIF: " + user.getNif());
            System.out.println("Email: " + user.getEmail());
            System.out.println("Dirección: " + user.getAddress());
            System.out.println("Fecha de nacimiento: " + user.getBirthdate());
            System.out.println("Rol: " + user.getRole());
        } else {
            System.out.println("No hay sesión iniciada.");
        }
    }

    public void logout() {
        System.out.println("\nSESIÓN CERRADA");
        logged = false;
        user = null;
    }

    private void readUsersFromFile() {
        try (Scanner scanner = new Scanner(new File(FILE_PATH + USERS_FILE))) {
            ArrayList<User> users = new ArrayList<>();

            while (scanner.hasNextLine()) {
                String[] userData = scanner.nextLine().split("#");
                User user = new User(userData[0], userData[1], userData[2], userData[3], userData[4], userData[5], userData[6]);
                user.setPassword(userData[7]);
                users.add(user);
            }

            setUsers(users);
        } catch (IOException e) {
            System.out.println("Error al leer el archivo de usuarios.");
        }
    }

    private void writeUsersToFile() {
        try (FileWriter writer = new FileWriter(FILE_PATH + USERS_FILE)) {
            for (User user : getUsersFromFile()) {
                String userData = String.join("#", user.getUsername(), user.getName(), user.getNif(), user.getEmail(),
                        user.getAddress(), user.getBirthdate(), user.getRole(), user.getPassword());

                writer.write(userData + System.lineSeparator());
            }
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo de usuarios.");
        }
    }

    private boolean isUsernameTaken(String username) {
        for (User storedUser : getUsersFromFile()) {
            if (username.equals(storedUser.getUsername())) {
                return true;
            }
        }
        return false;
    }

    private ArrayList<User> getUsersFromFile() {
        return users != null ? users : new ArrayList<>();
    }

    private void setUsers(ArrayList<User> users) {
        this.users = users;
    }
}



